import json
import boto3

TABLE_NAME = os.getenv('tableName')

def write_score(score_data):
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(TABLE_NAME)
    response = table.put_item(
        Item = score_data
    )
    print(response)

def lambda_handler(event, context):
    for record in event['Records']:
        if record['type'] == 'score' :
            body = json.loads(record["body"])
            print(body)
            write_score(body)